
// 더 이상 사용하지 않음 - 한국어만 사용
export function useTranslation() {
  const t = (key: string): string => {
    return key;
  };

  return { t };
}
