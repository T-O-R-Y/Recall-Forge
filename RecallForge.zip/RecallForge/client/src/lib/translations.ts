
// 더 이상 사용하지 않음 - 한국어만 사용
export const translations = {};
export type TranslationKey = string;
